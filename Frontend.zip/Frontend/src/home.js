import React, { Component } from "react";
import './App.css';
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import 'bootstrap/dist/css/bootstrap.min.css'



class Home extends Component{
    state ={stop1:[], stop2:[] }
    
    componentDidMount() {

        //For getting data for stop 1 
        setInterval( () => {
            fetch('/api/1')
            .then(res => res.json())
            .then(stop1 => this.setState({ stop1}))
          },1000)
       
        //for getting data for stop 2
        setInterval( () => {
            fetch('/api/2')
            .then(res => res.json())
            .then(stop2 => this.setState({ stop2}))
          },1000)

            
            // For live time update
            setInterval( () => {
                this.setState({
                  curTime : new Date().toLocaleString('en-GB')
                })
              },1000)

    }



render(){
  return (
     
    <div className="App">
    
     <Navbar bg="primary" variant="dark">
    <Container>
    <Navbar.Brand href="#home">Sample App</Navbar.Brand>
    <Nav className="me-auto">
      <Nav.Link href="https://www.linkedin.com/in/itsmeetkumarpatel/">MyLinkedIn</Nav.Link>
      <Nav.Link href="https://github.com/itsmeetkumar">My GitHub</Nav.Link>
      <Nav.Link href="https://github.com/itsmeetkumar/ReactProject">Project Repo</Nav.Link>
    </Nav>
    </Container>
  </Navbar>

  <Container>
    <h1>Current Time -{this.state.curTime} </h1>
    <br />
    {this.state.stop1.map(user => <h3> Stop : {user.StopID} Route:
           {user.Route} At {user.hours} : {user.Min} <br />
           </h3>)}
<hr />
           {this.state.stop2.map(user => <h3> Stop : {user.StopID} Route:
           {user.Route} At {user.hours} : {user.Min} <br />
           </h3>)}
    
  </Container>
    </div>
  );
}
}
export default Home;
